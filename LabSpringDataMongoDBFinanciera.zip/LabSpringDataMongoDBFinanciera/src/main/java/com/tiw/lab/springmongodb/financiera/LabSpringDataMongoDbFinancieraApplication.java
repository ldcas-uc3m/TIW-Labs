package com.tiw.lab.springmongodb.financiera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabSpringDataMongoDbFinancieraApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabSpringDataMongoDbFinancieraApplication.class, args);
	}

}
