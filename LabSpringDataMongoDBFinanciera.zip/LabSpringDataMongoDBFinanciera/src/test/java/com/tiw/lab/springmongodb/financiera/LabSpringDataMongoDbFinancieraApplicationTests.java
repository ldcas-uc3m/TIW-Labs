package com.tiw.lab.springmongodb.financiera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabSpringDataMongoDbFinancieraApplicationTests {

	@Test
	void contextLoads() {
	}

}
